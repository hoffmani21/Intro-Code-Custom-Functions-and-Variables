#include <kipr/botball.h>
int pause = 1000;
int speed = 60;
int lmotor = 0;
int rmotor = 2;
int main()
{

forward();
reverse();
turnleft();
turnright();

return 0;
}

void forward(){
motor(lmotor, speed);		//moves the motor plugged into port #0 forward at 60% power
motor(rmotor, speed);		//moves the motor plugged into port #2 forward at 60% power
printf("now initiating forward movement");
msleep(pause);		//allows motors to run for 4 seconds 
ao();
}

void reverse(){
motor(lmotor, -speed);		//moves the motor plugged into port #0 backward at 60% power
motor(rmotor, -speed);		//moves the motor plugged into port #2 backward at 60% power
msleep(pause);		//allows motors to run for 4 seconds 
printf("now initiating backward movement");
ao();
}

void turnleft(){
  motor(lmotor, -speed);		//moves the motor plugged into port #0 backward at 60% power
motor(rmotor, speed);		//moves the motor plugged into port #2 forward at 60% power
msleep(pause);		//allows motors to run for 4 seconds 
printf("now initiating a left turn");
ao();
}

void turnright(){
  motor(lmotor, speed);		//moves the motor plugged into port #0 forward at 60% power
motor(rmotor, -speed);		//moves the motor plugged into port #2 backward at 60% power
msleep(pause);		//allows motors to run for 4 seconds 
printf("now initiating a right turn");
ao();		//turns off all motors
}
}